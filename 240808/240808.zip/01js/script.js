// let stars = parseInt(prompt("별의 개수"));

// while (stars > 0) {
//   document.write("*");
//   stars--;
// }

// do {
//   document.write("*");
//   stars--;
// } while (stars > 0);

// let i = 20;

// while (i >= 10) {
//   if (i % 2 === 0) {
//     document.write(`<p class="blue">${i}</p>`);
//   } else {
//     document.write(`<p class="red">${i}</p>`);
//   }
//   i--;
// }

// let i = 10;

// do {
//   document.write("hello!", "<br/>");
//   i--;
// } while (i > 5);

// 사용자에게 어떤 숫자를 전달받을 예정!!
// 해당 숫자가 소수인지 여부 판단!!
// 소수 => 1과 자기 자신만 나눌 수 있는 숫자!!
// 단락회로평가!!!
// 전원버튼!!! => 어떤 조건문을 통한 조건값이 참인경우와 거짓인 경우를 대비해서 전원을 만들어 놓고 판단!!!

const number = parseInt(prompt("자연수를 입력하세요!"));
let isPrime;

if (number === 1) document.write(`${number}은 소수도 합성수도 아닙니다!`);
else if (number === 2) {
  document.write(`${number}는 소수입니다.`);
  isPrime = true;
} else {
  for (let i = 2; i < number; i++) {
    if (number % i === 0) {
      isPrime = false;
      break;
    } else {
      isPrime = true;
    }
  }
}

if (isPrime) document.write(`${number}은 소수입니다!`);
else document.write(`${number}는 소수가 아닙니다!`);
