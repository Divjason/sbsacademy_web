// const userAge = parseInt(prompt("당신의 나이를 알려주세요!", "ex. 20"));

// console.log(typeof userAge);

// const num01 = 10;

// const result = userAge + num01;
// console.log(result);

// if (userAge >= 20) {
//   alert("당신은 성인입니다!");
// } else {
//   alert("당신은 미성년자 입니다.");
// }

// const obj = {
//   name: "David",
//   age: 20,
//   address: "Seoul",
//   favorite: "music",
// };

// console.log(typeof obj);

// 반드시 문자의 자료형을 사용할 때에만 "" & '' & ``

// const test01 = 1;
// const test02 = "1";

// console.log(test01 === test02);

// console.log(test01);
// 변수 => 일반 x

// console.log("오늘은 즐거운 월요일");

// 객체는 key : value 구성된 한쌍의 property(속성)형태로 완성!!!

// const mon = "월요일";

// console.log(`오늘은 ${mon} 입니다.`);

// 3가지 부류!!

// 1) 예약어 : 이미 JS 내 저장되어있는 문법 체계 parseInt() // Number()

// 2) 변수명 : 카멜표기법 // 스네이크표기법 // 헝가리언표기법

// const user_age = 10;
// const Lucky = 7;

// // 3) Class : 객체지향 꼭 학습
// class User {
//   constructor(name, age) {
//     this.name = name;
//     this.age = age;
//   }
// }

// const userTest = new User("David", 20);
// console.log(userTest);

// // 4) 자바스크립트로 CSS스타일 속성 제어
// const button = document.querySelector("button");
// button.addEventListener("click", () => {
//   button.style.backgroundColor = "#000";
// });

// 배열 => 어떤 값 혹은 아이템 요소에 순번을 붙여서 데이터 관리!!!

// const obj1 = {

// }

const arr1 = ["spring", "summer", "fall", "winter"];
// 배열 안에 입력된 값들은 무조건 0번부터 시작!!!

// console.log(arr1);

// 무조건 전체 아이템 개수 - 1 => 해당 배열의 마지막 아이템의 순번!!!

console.log(arr1[arr1.length - 1]);

const func = () => {
  alert("오늘은 월요일이라서 너무 행복해!");
};

func();
