// 자바스크립트를 어려워할까?

// 자바스크립트 알고있어야 하는 문법 방대

// 아무리 문법을 외워도 => 사용하는 것은 다른이야기!!

// 먼저 한글로 작성!!

// 적정체중을 계산하는 공식
// (본인의 키 - 100) * 0.9 +- 5

const userName = prompt("당신의 이름을 말씀해주세요!");
const userHeight = parseInt(prompt("당신의 키를 입력하세요!"));
const userWeight = parseInt(prompt("당신의 몸무게를 입력해주세요!"));

const normalWeight = (userHeight - 100) * 0.9;
let result = userWeight >= normalWeight - 5 && userWeight <= normalWeight + 5;

result = result ? "적정체중 이시네요!" : "적정체중이 아닙니다!";

alert(`${userName}님, ${result}`);
