const stars = document.querySelectorAll(".stars .fa-star");
