const h1 = document.querySelector("h1");
const box = document.querySelector(".box");

let x = 0;
let y = 0;

window.addEventListener("mousemove", (e) => {
  x = e.pageX;
  y = e.pageY;

  h1.innerText = `x : ${x} y: ${y}`;
});

const loop = () => {
  box.style.top = `${x}px`;
  box.style.left = `${y}px`;

  window.requestAnimationFrame(loop);
};

loop();
