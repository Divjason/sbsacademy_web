// 1.우측 상단 트리거 버튼을 클릭한다

// 2.트리거 버튼이 클릭된다면, 이벤트가 발생

// 3.트리거 버튼이 x모양이 된다

// 4.gnb & sns 컨텐츠 출력된다

// 5.트리거 버튼을 다시 클릭하면 위에 기능이 원래대로 돌아간다

const trigger = document.querySelector(".trigger");
trigger.addEventListener("click", function() {
  const gnb = document.querySelector(".gnb > ul");
  const sns = document.querySelector(".sns");
  this.classList.toggle("active");
  gnb.classList.toggle("on");
  sns.classList.toggle("on");
})