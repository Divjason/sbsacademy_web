// 함수 선언 & 호출 실행!!!!

// 1) 기명함수 = 이름있는 함수
// function calcSum() {
//   let sum = 0;
//   for (let i = 1; i <= 10; i++) {
//     sum += i;
//   }
//   console.log(`1부터 10까지 더하면 ${sum} 입니다!`);
// }

// calcSum();

// 2) 익명함수
// const calcSum = function () {
//   let sum = 0;
//   for (let i = 1; i <= 10; i++) {
//     sum += i;
//   }
//   console.log(`1부터 10까지 더하면 ${sum} 입니다!`);
// };

// calcSum();

// 3) 화살표함수
// const calcSum = () => {
//   let sum = 0;
//   for (let i = 1; i <= 10; i++) {
//     sum += i;
//   }
//   console.log(`1부터 10까지 더하면 ${sum} 입니다!`);
// };

// calcSum();

// 호이스팅!!! = 끌어올리다!!
// function 함수 VS 화살표함수 x
// 함수 선언 & 호출 순서!!

// this 객체 사용여부
// 어떤 이벤트를 실행하고자 할 때, 해당 이벤트가 발생된 요소를 찾아오고자 할 때
// 화살표함수 => this 객체를 사용하면 => window
// function함수 => 이벤트가 발생된 요소!!

// document.write(`<h1>오늘은 신나는 금요일!</h1>`);

// const h1Tag = document.querySelector("h1");
// h1Tag.addEventListener("click", () => {
//   console.log(this);
//   this.style.backgroundColor = "crimson";
//   this.style.color = "#fff";
// });

const num01 = parseInt(prompt("첫번째 숫자를 입력하세요!"));

const num02 = parseInt(prompt("두번째 숫자를 입력하세요!"));

// const sum = (num01, num02) => {
//   let result = num01 + num02;
//   alert(`두 수의 합은 ${result} 입니다.`);
// };

const sum = (num01, num02) => {
  let result = num01 + num02;
  return result;
};

document.write(`${num01}과 ${num02}의 합은 ${sum(num01, num02)} 입니다!`);
