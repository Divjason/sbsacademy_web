const form = document.querySelector("form");
const originPrice = document.querySelector("#originPrice");
const saleRating = document.querySelector("#saleRating");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const origin = originPrice.value;
  const rating = saleRating.value;
  const savedPrice = origin * (rating / 100);
  const finalPrice = origin - savedPrice;

  const desc = document.querySelector(".desc");
  desc.innerHTML = `원래 가격은 ${origin} 입니다. 할인률은 ${rating}% 입니다. 할인금액은 ${savedPrice} 이며, 최종 할인된 가격은 ${finalPrice} 입니다.`;
});
