// let num1 = 1;
// let num2 = 2;

// num1 = 3;

// let sum = num1 + num2;

// console.log(sum);

// const str1 = "안녕하세요~ ";
// const str2 = "오늘은 금요일입니다!";

// str1 = "Hi!";

// const strSum = str1 + str2;
// console.log(strSum);

// let이라는 키워드로 변수를 선언하면, 이미 선언된 변수명으로는 다시 변수를 생성x

// 재선언 불가, 재할당 가능

// const 키워드로 변수를 선언하면, 재선언, 재할당 x

// 결론 : const 최우선 고려!!!
// 변수를 선언 => 재할당 혹은 재선언 자유롭게 언어x

// // A개발자
// var num01 = 1;
// var num02 = 2;

// // B개발자
// var num01 = 5;

// var sum = num01 + num02;

// console.log(sum);

// 숫자형
// const number = 1;

// console.log(typeof number);

// 문자열 => 따옴표(*큰/작은) + 백틱(`)
// const str = "hi";
// const str1 = "1";

// const result = `${str} Seoul`;
// console.log(result);

// console.log(typeof str1);

// console.log(number == str1);

// const sum = number + str;
// console.log(typeof sum);

// const name = prompt("당신의 이름을 입력하세요!");
// const classRoom = prompt("오늘 입장하실 강의실 호수를 입력하세요!");

// alert(`${name}님, 지금바로 ${classRoom}호 강의실로 올라오세요!`);

// console.log(10 < 5);

// 로그인!!!

// 여기는 고객의 정보가 담겨있는 서버입니다!
// const id = "sbsacademy";
// const pw = 12345;

// // 사용자가 로그인을 하는 공간입니다!
// const userId = prompt("당신의 아이디를 입력하세요!");

// if (id === userId) {
//   const userPw = Number(prompt("당신의 비밀번호를 입력하세요!"));
//   if (pw === userPw) {
//     alert(`${userId}님 격하게 환영합니다!`);
//   } else {
//     alert(`${userId}님 비밀번호를 재확인하세요!`);
//   }
// } else {
//   alert(`${userId}님 아이디 재확안하세요!`);
// }

const id01 = Symbol("private01");
const id02 = Symbol("private02");

console.log(id01 === id02);

const member01 = {
  name: "김다영",
  [id01]: 12345,
};

const member02 = {
  name: "김다영",
  [id02]: 12345,
};

console.log(member01);
console.log(member02);
