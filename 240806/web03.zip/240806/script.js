// const num01 = 1;
// const num02 = 2;

// const result = num01 % num02;

// console.log(result);

// let a = 10;
// a = --a;
// console.log(a);

// let x = 10;
// let y = 4;

// let result = x + y--;

// console.log(result);

// console.log(y);

// let num03 = 0;

// num03 = num03 + 3;

// num03 += 3;

// num03 *= 3;

// console.log(num03);

// const num04 = 7;
// const num05 = "7";

// console.log(num04 != num05);

// let x = 10;

// if(조건식 => true // false) {
//   명령문 // 실행문
// }

// if (x < 5) {
//   alert(`${x}는 5보다 작습니다!`);
// } else {
//   alert(`${x}는 5보다 무조건 큽니다!`);
// }

// const userName = prompt("당신의 이름을 입력하세요!");

// console.log(userName);

// 예외조항처리!!!

// if (userName === null) {
//   alert("취소를 클릭했습니다!");
// } else {
//   alert(`${userName}님 만나서 반갑습니다!~`);
// }

// const num = parseInt(prompt("당신이 좋아하는 숫자를 입력하세요!"));

// if (num % 2 === 0) {
//   alert(`${num}은 짝수입니다!`);
// } else {
//   alert(`${num}은 홀수입니다!`);
// }

const month = parseInt(prompt("현재는 몇 월 입니까?"));

if (month >= 9 && month <= 11) {
  alert("독서의 계절 가을이네요!");
} else if (month >= 6 && month <= 8) {
  alert("여행가기 좋은 여름이네요!");
} else if (month >= 3 && month <= 5) {
  alert("햇살 가득한 봄이네요!");
} else {
  alert("스키의 계절 겨울이네요!");
}
