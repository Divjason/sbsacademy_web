// const a = 10;
// let b = a;

// const obj1 = {
//   c: 10,
//   d: "ddd",
// };
// let obj2 = { ...obj1 };

// console.log(obj1, obj2);

// obj2.c = 20;

// console.log(obj1, obj2);

// b = 15;
// console.log(a, b);

// obj2.c = 20;
// console.log(obj1, obj2);

// 네이버 회사 개발자!!
// 웹페이지 리뉴얼: 신규가입 1000원 기본 제공
// 스마트스토어 : 상품 1개 구매 => 1000원 제공

// 전개연산자 구문!!!
