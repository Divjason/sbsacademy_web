const stars = document.querySelectorAll(".stars .fa-star");

stars.forEach((star, index) => {
  star.addEventListener("click", () => {
    stars.forEach((item) => {
      item.classList.remove("active");
    });

    for (let i = 0; i <= index; i++) {
      stars[i].classList.add("active");
    }
  });
});
