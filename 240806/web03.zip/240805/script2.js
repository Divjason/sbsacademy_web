// 사용자에게 3가지의 값을 받아보세요!!!
// 교통비 // 식비 // 음료비
// 위 3개의 값의 총합이 10000원을 초과하는 경우에는 알림창을 활용해서 용돈관리를 잘해주세요! // 10000원 이하인 경우에는 알림창을 활용해서 용돈관리 잘하셨어요!!!

const traffic = Number(prompt("교통비를 입력하세요!"));
const eat = Number(prompt("식비를 입력하세요!"));
const drink = Number(prompt("음료비를 입력하세요!"));

const normal = traffic + eat + drink;
let result = normal <= 10000;

result = result ? "용돈관리 잘하셨어요!" : "용돈관리를 잘해주세요!";

console.log(result);
