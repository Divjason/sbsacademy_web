/* 실제 마우스 커서 이동 좌표값 */
let x = 0;
let y = 0;

/* 마우스 커서를 따라다닐 요소의 좌표값 */
let targetX = 0;
let targetY = 0;

/* 마우스 커서 움직임의 속도 */
const speed = 0.1;

const cursorItem = document.querySelector(".cursorItem");

window.addEventListener("mousemove", (e) => {
  x = e.pageX;
  y = e.pageY;
});

const loop = () => {
  targetX += (x - targetX) * speed;
  targetY += (y - targetY) * speed;

  cursorItem.style.transform = `translate(${targetX}px, ${targetY}px)`;
  window.requestAnimationFrame(loop);
};

loop();

const circle = cursorItem.querySelector(".circle");
const buttonAll = document.querySelectorAll("a");
buttonAll.forEach((item) => {
  item.addEventListener("mouseenter", () => {
    circle.style.transform = "scale(0.3)";
  });
  item.addEventListener("mouseleave", () => {
    circle.style.transform = "scale(1)";
  });
});
