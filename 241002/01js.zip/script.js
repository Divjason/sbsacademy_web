const progressBar = document.querySelector(".bar");
const depthWrap = document.querySelector(".depthWrap");
const submarine = document.querySelector(".submarine");
const octopus = document.querySelector(".octopus");

window.addEventListener("scroll", () => {
  let scrollNum = window.scrollY;
  let documentHeight = document.body.scrollHeight - window.innerHeight;

  let per = ((scrollNum / documentHeight) * 100).toFixed(0);

  progressBar.style.width = `${per}%`;
  submarine.style.transform = `translateX(${per * 14}px)`;
  octopus.style.transform = `translateY(${-per * 1.3}%)`;
  depthWrap.querySelector("span").innerText = scrollNum;
});
