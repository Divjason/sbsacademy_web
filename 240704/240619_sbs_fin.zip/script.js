const femaleBtn = document.querySelector("#femalebtn");
const maleBtn = document.querySelector("#malebtn");

femaleBtn.addEventListener("click", () => {
  femaleBtn.querySelector("#femalebtn i").classList.add("filledA");
  maleBtn.querySelector("#malebtn i").classList.remove("filledB");
});

maleBtn.addEventListener("click", () => {
  femaleBtn.querySelector("#femalebtn i").classList.remove("filledA");
  maleBtn.querySelector("#malebtn i").classList.add("filledB");
});
