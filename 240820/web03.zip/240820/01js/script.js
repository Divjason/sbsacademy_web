document.querySelector("button").addEventListener("click", () => {
  document.body.style.backgroundColor = "green";
});

// window.onload = alert("안녕하세요!");

// 자바스크립트의 모든 요소들은 기본 속성 공통!!!
// 특정 요소에 이벤트가 발생하면, 무조건
