const userId = document.querySelector("#userId");
const result = document.querySelector("#result");

const userDataList = [
  { id: 123, name: "원빈" },
  { id: 1021, name: "현빈" },
  { id: 6021, name: "아이유" },
];

const findUser = (searchId) => {
  const targetData = userDataList.find((data) => data.id === searchId);

  if (targetData === undefined || targetData === null)
    result.innerText = "유저 검색결과 없음";

  result.innerText = targetData.name;
};

userId.addEventListener("keyup", (e) => {
  const searchId = parseInt(e.target.value);

  if (isNaN(searchId)) result.innerText = "숫자가 아닙니다!";

  findUser(searchId);
});
