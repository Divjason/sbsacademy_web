const btn = document.querySelector("button");

btn.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  if (btn.innerText === "다크모드") btn.innerText = "라이트모드";
  else btn.innerText = "다크모드";
});
