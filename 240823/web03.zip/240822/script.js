// 객체
// 1) 내장객체
// - 날짜객체

const today = new Date();
const year = today.getFullYear();
const month = today.getMonth() + 1;
const date = today.getDate();
let day = today.getDay();

switch (day) {
  case 0:
    day = "일요일";
    break;
  case 1:
    day = "월요일";
    break;
  case 2:
    day = "화요일";
    break;
  case 3:
    day = "수요일";
    break;
  case 4:
    day = "목요일";
    break;
  case 5:
    day = "금요일";
    break;
  case 6:
    day = "토요일";
    break;
}

// console.log(today, year, month, date, day);

// - 수학객체

const num = 2.1234;
const num01 = 2.678;

const maxNum = console.log(Math.max(10, 5, 8, 30));
const minNum = console.log(Math.min(10, 5, 8, 30));
const roundNum = console.log(Math.round(num01));
const floorNum = console.log(Math.floor(num01));
const ceilNum = console.log(Math.ceil(num));
const rndNum = console.log(Math.random());
const piNum = console.log(Math.PI);
