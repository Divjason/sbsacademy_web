// for (let i = 1; i <= 100; i++) {
//   if (i % 5 === 0 && i % 7 === 0) document.write(`<p class="red">${i}</p>`);
//   else if (i % 5 !== 0 && i % 7 === 0)
//     document.write(`<p class="green">${i}</p>`);
// }

// const redItem = document.querySelectorAll(".red");
// redItem.forEach((item) => {
//   item.style.color = "#f00";
// });

// const greenItem = document.querySelectorAll(".green");
// greenItem.forEach((item) => {
//   item.style.color = "#0f0";
// });

// for문을 활용해서 구구단!!!
for (let a = 2; a <= 9; a++) {
  document.write(`<h2>재미있는 구구단 ${a}단</h2>`);
  for (let b = 1; b <= 9; b++) {
    document.write(`${a} x ${b} = ${a * b}`);
    document.write(`<br/>`);
  }
}
