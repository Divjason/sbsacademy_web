// const num01 = 7;
// const num02 = 10;

// const result = num01 + num02;
// console.log(result);

// const webSite = prompt("네이버, 다음, 구글 중 즐겨사용하는 웹 포털사이트는?");

// let url = "";

// switch (webSite) {
//   case "구글":
//     url = "https://www.google.com";
//     break;
//   case "네이버":
//     url = "https://www.naver.com";
//     break;
//   case "다음":
//     url = "https://www.daum.net";
//     break;
// }

// if (url) {
//   window.location.href = url;
// }

// const score = parseInt(prompt("당신의 점수를 입력하세요!"));

// // 중첩 if문
// if (score !== null) {
//   if (score >= 90) alert("A학점");
//   else if (score >= 80) alert("B학점");
//   else alert("C학점");
// }

// 모든 프로그래밍 언어를 크게 2가지 부류로 나눠보세요!!!

// 실행문 기반 언어
// C언어 => 실행!

// 표현식문 기반 언어
// 파이썬 => 실행 => 출력!!

// 자바스크립트
// 실행문 && 표현식문
// 다중패러다임 언어

// const num1 = 10;
// const num2 = 20;

// let small;

// if (num1 < num2) {
//   small = num1;
// } else {
//   small = num2;
// }

// console.log(small);

// 삼항조건연산자!
// small = num1 < num2 ? num1 : num2;
// console.log(small);

// 기본 for문
// const fruits = [
//   "apple",
//   "grape",
//   "watermelon",
//   "banana",
//   "strawberry",
//   "fineapple",
// ];

// for (let i = 0; i < fruits.length; i++) {
//   console.log(fruits[i]);
// }

// for (let fruit of fruits) {
//   console.log(fruit);
// }

// fruits.forEach((fruit, index) => {
//   console.log(`${index + 1} 번째 과일은 ${fruit} 입니다.`);
// });

const jsBook = {
  title: "재미있는 자바스크립트",
  pages: 272,
  published: "2024-08-09",
};

for (let key in jsBook) {
  console.log(`${key}은 ${jsBook[key]}`);
}
