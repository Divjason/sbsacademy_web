const today = new Date();
const toNow = today.getTime();
const firstDay = new Date("2024-06-14");
const toFirst = firstDay.getTime();
const passedTime = toNow - toFirst;
const passedDay = passedTime / (24 * 60 * 60 * 1000);
console.log(passedDay);

// 프로그래밍 영역만의 특징!!
// 1) 웹좌표계 <-> 데카르트

// 2) 호도법 <-> 60분법

// 3) 초 <-> 밀리초

// 1초 = 1000밀리초
// 1분 = 60초 = (60 * 1000)
// 1시간 = 60분 = (60 * 60 * 1000)
// 1일 = 24시간 = (24 * 60 * 60 * 1000)
// 1970년 1월 1일
