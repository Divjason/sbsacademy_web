// html을 통해서 만들어내는 그 모든 문서는 다 객체화되고 있음
// const pItems = document.querySelectorAll("p");
// console.log(pItems);

const textNode = document.createTextNode("Typescript");
const newP = document.createElement("p");

newP.appendChild(textNode);
document.body.appendChild(newP);

console.log(newP);
