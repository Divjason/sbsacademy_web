// Search Modal
const searchBtn = document.querySelector(".fa-magnifying-glass");
const cloneBtn = document.querySelectorAll(".close, section");

searchBtn.addEventListener("click", () => {
  document.querySelector(".modal-search").classList.add("active");
});

cloneBtn.forEach((item) => {
  item.addEventListener("click", () => {
    document.querySelector(".modal-search").classList.remove("active");
  });
});
