// const form = document.querySelector("form");
// form.addEventListener("submit", (e) => {
//   e.preventDefault();
//   // const product = document.querySelector("#product").value;
//   // console.log(product);
// });
const testAns = document.querySelector(`form[name="order"]`);

testAns.addEventListener("submit", (e) => {
  e.preventDefault();
  const product = document.querySelector("#product").value;
  console.log(product);
});

// const testValue = document.forms[0].elements[0];
// console.log(testValue);

// const promotion = document.querySelector("#promotion");

// promotion.addEventListener("change", () => {
//   let selectedText = promotion.options[promotion.selectedIndex].innerText;
//   alert(`고객님께서는 ${selectedText}를 선택하셨습니다!`);
// });

const radioEvent = document.querySelectorAll('input[name="event1"]');
radioEvent.forEach((item) => {
  item.addEventListener("change", (e) => {
    alert(`고객님이 선택한 이벤트는 ${e.target.value} 입니다!`);
  });
});

const checkEvent = document.querySelectorAll('input[name="event2"]');
checkEvent.forEach((item) => {
  item.addEventListener("change", (e) => {
    alert(`고객님이 선택한 메일링은 ${e.target.value} 입니다!`);
  });
});
