const viewBtn = document.querySelector("#view");
viewBtn.addEventListener("click", () => {
  document.querySelector("#detail").classList.toggle("hidden");
});
