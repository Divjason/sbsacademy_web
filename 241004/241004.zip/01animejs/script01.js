anime({
  targets: ".box1",
  translateX: 250,
  easing: "linear",
  loop: true,
  background: "#000",
  direction: "alternate",
  borderRadius: "50%",
});

anime({
  targets: ".box2",
  translateX: 280,
  translateY: 300,
  easing: "easeInQuart",
  duration: 1000,
  loop: true,
  direction: "alternate",
});

anime({
  targets: ".box3",
  translateX: {
    value: 400,
    duration: 1500,
    delay: 1000,
  },
  rotate: {
    value: 360,
    duration: 1200,
    delay: 1500,
  },
});
