anime({
  targets: "ul li",
  translateY: (el, i) => {
    if (i % 2 === 0) {
      return 80;
    } else {
      return -80;
    }
  },
  opacity: 1,
  easing: "linear",
  duration: 1500,
  delay: anime.stagger(300),
  loop: true,
  direction: "alternate",
});
