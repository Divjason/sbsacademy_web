const API_KEY = "63f74653bc784125c8b0dea992eb3d70";

export default { API_KEY };
