import env from "./env.js";

const getCurrentWeather = (latitude, longitude) => {
  const URL = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${env.API_KEY}&units=metric`;

  fetch(URL)
    .then((response) => response.json())
    .then((data) => {
      console.log(data);
      const icon = document.querySelector(".icon");
      const temp = document.querySelector(".temp");
      const weather = document.querySelector(".weather");
      const city = document.querySelector(".city");

      let weatherName;
      switch (data.weather[0].main) {
        case "Clear":
          weatherName = "🌞오늘 맑음";
          break;
      }

      let cityName;
      switch (data.name) {
        case "Yongsan":
          cityName = "서울시 용산구 🌈";
          break;
      }

      icon.src = `https://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png`;
      temp.innerText = `${data.main.temp} ℃`;
      weather.innerText = weatherName;
      city.innerText = cityName;
    });
};

const getPosition = (position) => {
  const { latitude, longitude } = position.coords;
  getCurrentWeather(latitude, longitude);
};

const errorPosition = (err) => {
  const noti = document.querySelector(".noti");
  noti.style.display = "block";
  alert(err.message);
};

if (navigator.geolocation)
  navigator.geolocation.getCurrentPosition(getPosition, errorPosition);
else alert("Geolocation is not Available");
