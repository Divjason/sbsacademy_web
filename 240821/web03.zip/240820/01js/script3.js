const btn = document.querySelector("#btn");
const nav = document.querySelector("#nav");

btn.addEventListener("click", function () {
  this.classList.toggle("active");
  nav.classList.toggle("active");
});
