const form = document.querySelector("form");
const input = document.querySelector('input[type="text"]');
const ul = document.querySelector("ul");

const delItem = (e) => {
  const target = e.target.parentElement;
  target.remove();
};

const addItem = (text) => {
  if (text !== "") {
    const li = document.createElement("li");
    const span = document.createElement("span");
    const button = document.createElement("button");

    span.innerText = text;
    button.innerText = "삭제하기";
    button.addEventListener("click", (e) => {
      delItem(e);
    });

    li.append(span, button);
    ul.prepend(li);
  }
};

const handler = (e) => {
  e.preventDefault();
  addItem(input.value);
  input.value = "";
};

form.addEventListener("submit", (e) => {
  handler(e);
});
