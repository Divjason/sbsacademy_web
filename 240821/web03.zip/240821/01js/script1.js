const orderBtn = document.querySelector("#order");
const title = document.querySelector("#container h2");

orderBtn.addEventListener(
  "click",
  () => {
    const orderInfo = document.querySelector("#orderInfo");
    const newP = document.createElement("p");
    const textNode = document.createTextNode(title.innerText);

    const newImg = document.createElement("img");
    const srcNode = document.createAttribute("src");
    srcNode.value =
      "https://contents.kyobobook.co.kr/sih/fit-in/458x0/pdt/9791188331796.jpg";

    newImg.setAttributeNode(srcNode);

    newP.appendChild(textNode);
    newP.style.fontSize = "1.4rem";
    newP.style.color = "#00f";
    orderInfo.appendChild(newP);
    orderInfo.appendChild(newImg);
  },
  { once: true }
);
