import { API_KEY } from "./env.js";

const URL = `https://api.themoviedb.org/3/movie/popular?api_key=${API_KEY}&language=ko&page=1`;

const createBlock = ({
  id,
  poster_path,
  original_title,
  title,
  vote_average,
  release_date,
}) => {
  const contents = document.querySelector(".contents");
  const movie = document.createElement("div");
  const poster = document.createElement("img");
  const detail = document.createElement("div");

  movie.className = "movie";
  detail.className = "detail";

  poster.src = `https://image.tmdb.org/t/p/original/${poster_path}`;

  movie.append(poster, detail);
  contents.append(movie);
};

fetch(URL)
  .then((response) => response.json())
  .then(({ results }) =>
    results.forEach((movie) => {
      createBlock(movie);
    })
  );
