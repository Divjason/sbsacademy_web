const h1 = document.querySelector("h1");
const progressBar = document.querySelector(".bar");

window.addEventListener("scroll", () => {
  let scrollNum = window.scrollY;
  let documentHeight = document.body.scrollHeight - window.innerHeight;

  let per = ((scrollNum / documentHeight) * 100).toFixed(0);
  h1.innerText = `${per}%`;
  progressBar.style.width = `${per}%`;
});
