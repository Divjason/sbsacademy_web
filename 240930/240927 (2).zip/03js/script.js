/* 실제 마우스 커서 좌표값 */
let x = 0;

/* 마우스 이동에 따른 시차 좌표값 */
let targetX = 0;

/* 실제 및 시차 좌표값에 대한 인터벌 속도 */
const speed = 0.1;

/* 이미지를 찾아오는 요소 */
const contentAll = document.querySelectorAll(".contWrap img");
const shadow = contentAll[0];
const date = contentAll[1];
const human = contentAll[2];
const textImg = contentAll[3];

window.addEventListener("mousemove", (e) => {
  x = e.pageX - window.innerWidth / 2;
});

const loop = () => {
  targetX += (x - targetX) * speed;
  shadow.style.transform = `translateX(${targetX / 35}px)`;
  date.style.transform = `translateX(${targetX / 20}px)`;
  human.style.transform = `translateX(${-targetX / 20}px)`;
  textImg.style.transform = `translateX(${-targetX / 10}px)`;
  window.requestAnimationFrame(loop);
};

loop();
