const songs = document.querySelectorAll(".albumTable_song");

songs.forEach((song) => {
  const playBtn = song.querySelector(".fa-play");
  const pauseBtn = song.querySelector(".fa-pause");
  playBtn.addEventListener("click", (e) => {
    e.target.closest("td").querySelector("audio").play();
  });
  pauseBtn.addEventListener("click", (e) => {
    e.target.closest("td").querySelector("audio").pause();
  });
});
