// Word Game
const gameForm = document.querySelector(".word_text form");
const gameStart = (e) => {
  e.preventDefault();
  let myword = document.querySelector("#myword").value;
  let word = document.querySelector("#word").innerText;
  let lastword = word[word.length - 1];
  let firstword = myword[0];
  if(lastword === firstword) {
    document.querySelector("#result").innerText = "정답입니다!";
    document.querySelector("#word").innerText = myword;
    document.querySelector("#myword").value = "";
  } else {
    document.querySelector("#result").innerText = "틀렸습니다!";
    document.querySelector("#myword").value = "";
  }
}
gameForm.addEventListener("submit", gameStart);

// Lotto Game
// 1~45까지의 숫자
// 총 6개의 숫자 추첨
// 반드시 중복 x

const button = document.querySelector(".wrapper_lotto_btn");
const result = document.querySelector(".game_lotto_number");

const luckyNumber = {
  digitCount: 6,
  maxNumber: 45
};

const startLotto = () => {
  const {digitCount, maxNumber} = luckyNumber;
  let myNumber = new Set();
  for(let i = 0; i < digitCount; i++) {
    myNumber.add(Math.floor(Math.random() * maxNumber) + 1);
  }
  if(myNumber.size === 6) {
    result.innerText = `${[...myNumber]}`;
  } else {
    result.innerText = `재추첨하겠습니다!`;
  }
};

button.addEventListener("click", startLotto);