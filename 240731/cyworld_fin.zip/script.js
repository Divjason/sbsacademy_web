// Navigation
const menuHome = document.querySelector("#menuHome");
const menuGame = document.querySelector("#menuGame");
const menuJukeBox = document.querySelector("#menuJukebox");
const contentFrame = document.querySelector("#contentFrame");

const homeChange = () => {
  contentFrame.setAttribute("src", "./home.html");
  menuHome.style = "background: #fff; color: #000";
  menuGame.style = "background: #298eb5; color: #fff";
  menuJukeBox.style = "background: #298eb5; color: #fff";
};

const gameChange = () => {
  contentFrame.setAttribute("src", "./game.html");
  menuHome.style = "background: #298eb5; color: #fff";
  menuGame.style = "background: #fff; color: #000";
  menuJukeBox.style = "background: #298eb5; color: #fff";
};

const jukeboxChange = () => {
  contentFrame.setAttribute("src", "./jukebox.html");
  menuHome.style = "background: #298eb5; color: #fff";
  menuGame.style = "background: #298eb5; color: #fff";
  menuJukeBox.style = "background: #fff; color: #000";
};

menuHome.addEventListener("click", homeChange);
menuGame.addEventListener("click", gameChange);
menuJukeBox.addEventListener("click", jukeboxChange);
