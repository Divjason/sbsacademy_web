const hTag = document.querySelector("h1");
hTag.addEventListener("click", () => {
  if (hTag.classList.contains("active")) {
    hTag.classList.remove("active");
  } else {
    hTag.classList.add("active");
  }
});

const pTag = document.querySelectorAll("p");

pTag[1].addEventListener("click", function () {
  this.innerHTML = `<h1 style="color: #f00; border: 1px solid #f00">이름 : 태연</h1>`;
});

// DOM을 활용해서 html 요소를 찾아오고자 할 때, 3가지 요소 사용가능!!!

// innerHTML : 문자 뿐만 아니라 html 태그 및 속성요소들까지도 인식!!!

// innerText : 해당 속성을 활용해서 무조건 텍스트 문자열만 주고, 받을 수 있음

// textContent : 해당 속성 역시 모든 데이터를 문자화 합니다!!

// const desc = document.querySelector(".desc");

// console.log(desc.textContent);

// textContent는 innerHTML을 통해서 찾아온 DOM 요소에서 html 태그 요소만 제거한 것!!!

// innerText는 애초에 화면상에 보여지는 text만 추출해서 가져온 것!!!
