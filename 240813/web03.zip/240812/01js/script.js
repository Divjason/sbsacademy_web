// const button = document.querySelector("button");

// const display = () => {
//   alert("클릭했습니다!");
// };

// button.addEventListener("click", display);

// 선언 => 호출
// 콜백함수 => 함수들간의 구조적인 형태
// 콜백함수 == 화살표함수
// 화살표함수 => 물리적인 함수의 형태

// const callback = (userName, userAge) => {
//   alert(`안녕하세요! ${userName}님! 나이가 ${userAge}이시군요!`);
// };

// const getData = (callback) => {
//   const userName = prompt("당신의 이름을 입력해주세요!");
//   const userAge = parseInt(prompt("당신의 나이를 입력하세요!"));
//   callback(userName, userAge);
// };

// getData(callback);

// 자바스크립트 함수 => 1급시민!!! => 특급시민
// 특별하다!!
// 파이썬, C언어, 자바

// 1) 함수가 다른 함수의 매개변수로 입력
// 2) 함수를 일반 변수에 할당할 수 있어야
// 3) 함수를 다른 함수의 반환값으로 사용할 수 있어야

// const add = (a, b) => {
//   const result = a + b;
//   return result;
// };

// const init = () => {
//   return (a, b) => {
//     return a - b > 0 ? a - b : b - a;
//   };
// };

// console.log(init()(10, 20));

// 내장함수
// setInterval() => 시차를 가지고 반복적 실행!!!
// clearInterval() => setInterval함수를 종료!!!
// setTimeout() => 특정 시간 이후에 실행!!!

// const greeting = () => {
//   console.log("안녕하세요!");
// };

// setInterval(greeting, 1000);

// let counter = 0;

// const timer = setInterval(() => {
//   console.log("안녕하세요!");
//   counter++;

//   if (counter === 5) {
//     clearInterval(timer);
//   }
// }, 2000);

setTimeout(() => {
  console.log("이제 3초가 지났습니다!");
}, 3000);
