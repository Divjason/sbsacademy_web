const today = new Date();
const toNow = today.getTime();
const firstDay = new Date("2024-06-14");
const toFirst = firstDay.getTime();
const passedTime = toNow - toFirst;
const passedDay = Math.round(passedTime / (24 * 60 * 60 * 1000));
const accent = document.querySelector(".accent");
accent.innerText = `${passedDay} 일`;

// 100일
let future = toFirst + 100 * (24 * 60 * 60 * 1000);
let someday = new Date(future);
let year = someday.getFullYear();
let month = someday.getMonth() + 1;
let date = someday.getDate();
document.querySelector("#date100").innerText = `${year}년 ${month}월 ${date}일`;

// 200일
future = toFirst + 200 * (24 * 60 * 60 * 1000);
someday = new Date(future);
year = someday.getFullYear();
month = someday.getMonth() + 1;
date = someday.getDate();
document.querySelector("#date200").innerText = `${year}년 ${month}월 ${date}일`;

// 365일
future = toFirst + 365 * (24 * 60 * 60 * 1000);
someday = new Date(future);
year = someday.getFullYear();
month = someday.getMonth() + 1;
date = someday.getDate();
document.querySelector("#date365").innerText = `${year}년 ${month}월 ${date}일`;

// 500일
future = toFirst + 500 * (24 * 60 * 60 * 1000);
someday = new Date(future);
year = someday.getFullYear();
month = someday.getMonth() + 1;
date = someday.getDate();
document.querySelector("#date500").innerText = `${year}년 ${month}월 ${date}일`;

// 프로그래밍 영역만의 특징!!
// 1) 웹좌표계 <-> 데카르트

// 2) 호도법 <-> 60분법

// 3) 초 <-> 밀리초

// 1초 = 1000밀리초
// 1분 = 60초 = (60 * 1000)
// 1시간 = 60분 = (60 * 60 * 1000)
// 1일 = 24시간 = (24 * 60 * 60 * 1000)
// 1970년 1월 1일
