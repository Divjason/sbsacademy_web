// 자바스크립트는 동기처리방식의 싱글스레드 언어이며, 동시에 객체지향 프로토타입 기반의 프로그래밍 언어!

// html로 작성한 모든 태그를 객체

const book1 = {
  title: "자바스크립트",
  pages: 348,
};

// 온점표기법 // 대괄호표기법
console.log(book1.title);
console.log(book1["pages"]);

const book2 = new Object();

book2.title = "typescript";
book2["pages"] = 648;

console.log(book2);

let student = {
  name: "David",
  score: {
    history: 85,
    science: 94,
    average: function () {
      return (this.history + this.science) / 2;
    },
  },
};

console.log(student.score.history);
console.log(student.score.science);
console.log(student.score.average());
